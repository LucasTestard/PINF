<?php


// inclure ici la librairie faciliant les requêtes SQL
include_once("maLibSQL.pdo.php");


function listerUtilisateurs($classe = "both")
{
	// NB : la présence du symbole '=' indique la valeur par défaut du paramètre s'il n'est pas fourni
	// Cette fonction liste les utilisateurs de la base de données 
	// et renvoie un tableau d'enregistrements. 
	// Chaque enregistrement est un tableau associatif contenant les champs 
	// id,pseudo,blacklist,connecte,couleur

	// Lorsque la variable $classe vaut "both", elle renvoie tous les utilisateurs
	// Lorsqu'elle vaut "bl", elle ne renvoie que les utilisateurs blacklistés
	// Lorsqu'elle vaut "nbl", elle ne renvoie que les utilisateurs non blacklistés

	$SQL = "select * from users";
/*	if ($classe == "bl")
		$SQL .= " where blacklist=1";
	if ($classe == "nbl")
		$SQL .= " where blacklist=0";*/
	
	// echo $SQL;
	return parcoursRs(SQLSelect($SQL));

}


function interdireUtilisateur($idUser)
{
	// cette fonction affecte le booléen "blacklist" à vrai
	$SQL = "UPDATE users SET blacklist=1 WHERE id='$idUser'";
	// les apostrophes font partie de la sécurité !! 
	// Il faut utiliser addslashes lors de la récupération 
	// des données depuis les formulaires

	SQLUpdate($SQL);
}

function autoriserUtilisateur($idUser)
{
	// cette fonction affecte le booléen "blacklist" à faux 
	$SQL = "UPDATE users SET blacklist=0 WHERE id='$idUser'";
	SQLUpdate($SQL);
}

function verifUserBdd($login,$passe)
{
	// Vérifie l'identité d'un utilisateur 
	// dont les identifiants sont passes en paramètre
	// renvoie faux si user inconnu
	// renvoie l'id de l'utilisateur si succès

	$SQL="SELECT id FROM users WHERE pseudo='$login' AND passe='$passe'";

	return SQLGetChamp($SQL);
	// si on avait besoin de plus d'un champ
	// on aurait du utiliser SQLSelect
}
function creerFicheInformationComplete($dateRedaction, $idConducteur, $nomClient, 
$heureRedaction, $immatricualtion, $nomEtab, $ponctualite, $motif,	
$reservation, $dateIncident, $heureIncident, $vehicules, $circonstances, 
$infoReclamation, $actionConduteur, $serviceAdmin, $dateAdmin, $descriptionTraitement)
{
//	$heure+= 00;
//	echo $heure;
	$SQL="INSERT INTO fiche_information	(date_redaction, id_user, nom_client, heure_redaction, id_vehicule, 
	nom_etablissement, retard, motif_retard, difficulte_reservation, 
	date_incident , heure_incident ,vehicule_panne_accident, circonstance_panne_accident,autre_info_reclamation,
 	actions_conducteur , traitement_id_superuser, traitement_date, traitement_desc ) 
		VALUES ('$dateRedaction',$idConducteur, '$nomClient', '$heureRedaction', '$immatricualtion',
		'$nomEtab', '$ponctualite' , '$motif',	'$reservation' ,'$dateIncident', '$heureIncident', '$vehicules', '$circonstances', 
'$infoReclamation', '$actionConduteur', '$serviceAdmin', $dateAdmin, '$descriptionTraitement')" ;
	
	SQLInsert($SQL);
}
function creerFicheInformationIncomplete($dateRedaction, $idConducteur, $nomClient, 
$heureRedaction, $immatricualtion, $nomEtab)
{
	$SQL="INSERT INTO fiche_information	(date_redaction, id_user, nom_client, heure_redaction, id_vehicule, 
		nom_etablissement) 
		VALUES ('$dateRedaction',$idConducteur, '$nomClient', '$heureRedaction', '$immatricualtion',
		'$nomEtab')" ;
	SQLInsert($SQL);
}

function chercherDernierIdFicheInfo()
{
	$SQL = "SELECT MAX(id) AS dernierId FROM fiche_information";
	return SQLGetChamp($SQL);
}

function insererPonctualiteFicheInfo($ponctualite, $idFicheInfo)
{
	$SQL = "UPDATE fiche_information SET retard='$ponctualite' WHERE id='$idFicheInfo'";
	SQLUpdate($SQL);
}

function insererMotifFicheInfo($motif,$idFicheInfo)
{
	$SQL = "UPDATE fiche_information SET motif_retard='$motif' WHERE id='$idFicheInfo'";
	SQLUpdate($SQL);
}

function insererReservationFicheInfo($reservation,$idFicheInfo)
{
	$SQL = "UPDATE fiche_information SET difficulte_reservation='$reservation' WHERE id='$idFicheInfo'";
	SQLUpdate($SQL);
}

function insererDateIncidentFicheInfo($dateIncident,$idFicheInfo)
{
	$SQL = "UPDATE fiche_information SET date_incident='$dateIncident' WHERE id='$idFicheInfo'";
	SQLUpdate($SQL);
}

function insererHeureIncidentFicheInfo($heureIncident,$idFicheInfo)
{
	$SQL = "UPDATE fiche_information SET heure_incident='$heureIncident' WHERE id='$idFicheInfo'";
	SQLUpdate($SQL);
}

function insererVehiculesFicheInfo($vehicules,$idFicheInfo)
{
	$SQL = "UPDATE fiche_information SET vehicule_panne_accident='$vehivules' WHERE id='$idFicheInfo'";
	SQLUpdate($SQL);
}

function insererCirconstancesFicheInfo($circonstances, $idFicheInfo)
{
	$SQL = "UPDATE fiche_information SET circonstance_panne_accident='$circonstances' WHERE id='$idFicheInfo'";
	SQLUpdate($SQL);
}

function insererInfoReclamationFicheInfo($infoReclamation, $idFicheInfo)
{
	$SQL = "UPDATE fiche_information SET autre_info_reclamation='$infoReclamation' WHERE id='$idFicheInfo'";
	SQLUpdate($SQL);
}

function insererActionConducteurFicheInfo($actionConducteur, $idFicheInfo)
{
	$SQL = "UPDATE fiche_information SET actions_conducteur='$actionConducteur' WHERE id='$idFicheInfo'";
	SQLUpdate($SQL);
}

function insererServiceAdminFicheInfo($serviceAdmin, $idFicheInfo)
{
	$SQL = "UPDATE fiche_information SET traitement_id_superuser='$serviceAdmin' WHERE id='$idFicheInfo'";
	SQLUpdate($SQL);
}

function insererDateAdminFicheInfo($dateAdmin,$idFicheInfo)
{
	$SQL = "UPDATE fiche_information SET  traitement_date='$dateAdmin' WHERE id='$idFicheInfo'";
	SQLUpdate($SQL);
}

function insererDescriptionTraitementFicheInfo($descriptionTraitement, $idFicheInfo)
{
	$SQL = "UPDATE fiche_information SET traitement_desc='$descriptionTraitement' WHERE id='$idFicheInfo'";
	SQLUpdate($SQL);
}

?>
